BallFX v37 — Hand Position Patch Only

Purpose
- Fixes Recall Effect appearing near the neck/chest instead of the player's hand.
- First-person and third-person attachable offsets are lowered toward the right-hand area.
- Moves the body-relative beam origin down from 1.15 to 0.82 blocks and slightly toward the right hand.
- Keeps player-body yaw anchoring; no camera pitch is introduced.

Files
- PokeBEHavior/scripts/index.js: only recallEffectItemId() and handBallPos() logic changed from the v33 baseline.
- PokeBEHavior/items/recall_effect_*.json: adds minecraft:hand_equipped=true to all 50 temporary recall items.
- PokeRES/animations/recall_effect.animation.json: adjusts only first-/third-person hand poses; open/idle lid animation, geometry and scale stay unchanged.

Install
1. Behavior Pack: replace scripts/index.js with the included file.
2. Behavior Pack: merge the 50 items under items/ (overwrite matching recall_effect_*.json).
3. Resource Pack: merge PokeRES/animations/recall_effect.animation.json.
4. Keep the existing v35 Recall attachables and geometry. No Mega Ring, PokéBedrock GUI, unrelated models, or textures are included.
5. Disable older Recall test packs/duplicates to avoid override conflicts.

Validation
- Node.js syntax check passed.
- All 51 JSON files parsed.
- 50/50 Behavior item identifiers match 50/50 Resource Pack attachable identifiers.
- ZIP integrity checked after creation.
- Not tested in a running Minecraft client; hand offsets are best-effort and may need a small in-game adjustment for the player's selected skin/animation context.
