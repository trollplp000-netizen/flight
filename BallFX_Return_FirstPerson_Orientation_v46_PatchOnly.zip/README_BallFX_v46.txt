BallFX v46 — First-person orientation correction (Patch Only)

Why v45 was wrong
- v45 inserted fp_pose at pivot [0, 4, 0] and counter-rotated it by +117.5 degrees.
- Because the compensation pivot was not the root origin, the two rotations did not cancel cleanly in world space. The mesh was translated out of the first-person hand view, leaving only a corner visible and making its facing direction inconsistent.

What v46 changes
- Removes the fp_pose compensation bone completely.
- Restores the same first-person root transform used by the addon’s normal held Poké Ball:
  rotation [0, 0, -117.5], position [1, 25, -4].
- Keeps Recall scale [0.5, 0.5, 0.5].
- Keeps the geometry hierarchy as pokeball -> ball -> bottom -> lid; root retains the item-slot binding.
- Keeps the accepted third-person pose [0, 21, -5], scale 0.5.
- Keeps the open/open_idle animation curves unchanged.

Files to overwrite in PokeRES
- models/entity/recall_effect_pokeball.geo.json
- animations/recall_effect.animation.json

No Behavior Pack, index.js, attachables, item definitions, textures, Mega Ring or GUI files are changed.
Disable older Recall patches (especially v45) so they do not override these two files.

Validation
- Both JSON files parse.
- No fp_pose bone or animation references remain.
- Every animated bone (pokeball, ball, bottom, lid) exists in geometry.
- Root binding expression is retained.
- First-person transform matches the stock ball hold transform.
- Third-person transform is preserved from v44/v45.
- ZIP integrity checked.
- Not launched in Minecraft in this environment; in-game render still requires testing.
