BallFX v39 — Recall hand anchor + first-person visibility patch

Scope
- Fixes only Recall Effect held-ball rendering for all 50 ball types.
- Does not modify index.js, Mega Ring, PokéBedrock GUI, or any unrelated texture/model.

Key corrections
- Restores the v37 third-person hand offset [-4, 11, -5]; v38 had reverted it to the old [0, 21, -5] pose.
- Uses an explicit Recall first-person pose matching the original working Poké Ball first-person transform, scaled to the Recall model.
- Switches first/third-person animations with context.is_first_person == 1.0 / 0.0, following current Bedrock attachable examples.
- Removes minecraft:hand_equipped from all 50 Recall Effect items. The original Poké Ball Behavior item definitions do not set this component; it changes the held item to tool-like rendering.
- Keeps the existing root bone name `pokeball`, item-slot binding q.item_slot_to_bone_name(context.item_slot), scale 0.5, open/idle lid animations, textures, and recall controller.
- Adds the original enchanted texture/material mapping to match the working Poké Ball attachables.

Install
1. In Behavior Pack, overwrite the 50 files under PokeBEHavior/items/recall_effect_*.json with the ones in this patch. Do NOT replace scripts/index.js.
2. In Resource Pack, merge all files under PokeRES/ into the existing PokeRES.
3. Disable/remove older Recall test Resource Packs v32-v38 so only one copy of each recall_effect attachable and animation is active.
4. Keep the normal ball attachables in PokeRES/attachables/balls/ unchanged.

Validation
- 50/50 Behavior item identifiers match 50/50 Resource Pack attachable identifiers.
- 50/50 recall texture paths exist in the original PokeRES.zip.
- Geometry root bone and animation bone names validated.
- JSON parse: all passed. ZIP CRC: validated.
- Not launched in Minecraft in this environment; final first-person visibility must still be tested in the client.
